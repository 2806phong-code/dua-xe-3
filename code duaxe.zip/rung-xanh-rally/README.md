# Rừng Xanh Rally

Game đua xe 2D phong cách arcade, chạy trực tiếp trên trình duyệt.

## Tính năng
- Chọn 5 phương tiện: xe đạp, xe máy, xe lăn, xe lu, xe ba gác.
- Đường đua trong rừng với hiệu ứng phối cảnh và cây nhiều lớp.
- Thú hoang xuất hiện bất ngờ, băng qua đường đua.
- Kỹ năng tăng tốc có thời lượng, thời gian hồi và hiệu ứng.
- Âm thanh hiệu ứng và nhạc nền tạo bằng Web Audio API.
- Điểm số, tốc độ, kỷ lục lưu trên trình duyệt.
- Điều khiển bàn phím và nút cảm ứng trên điện thoại.

## Chạy thử
Mở `index.html` bằng trình duyệt hiện đại. Bấm Bắt đầu để kích hoạt âm thanh (trình duyệt yêu cầu thao tác của người dùng).

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub.
2. Tải `index.html` lên thư mục gốc của repository.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch**, branch `main`, folder `/(root)`, rồi **Save**.
5. Mở đường dẫn GitHub Pages được hiển thị sau khi xuất bản.
